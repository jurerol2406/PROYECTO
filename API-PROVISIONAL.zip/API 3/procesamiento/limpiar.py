import cv2
import numpy as np

def limpiar_imagen(img_bgr):
    if img_bgr is None or img_bgr.size == 0:
        raise ValueError("Imagen vacía o inválida")

    if len(img_bgr.shape) == 2:
        gray = img_bgr.copy()
    elif len(img_bgr.shape) == 3 and img_bgr.shape[2] == 4:
        gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGRA2GRAY)
    elif len(img_bgr.shape) == 3 and img_bgr.shape[2] == 3:
        gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    else:
        raise ValueError(f"Número de canales inesperado: {img_bgr.shape}")

    gray = cv2.equalizeHist(gray)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    bordes = cv2.Canny(blur, 50, 150)

    if bordes is None or bordes.size == 0:
        bordes = np.zeros_like(gray, dtype=np.uint8)

    return bordes
