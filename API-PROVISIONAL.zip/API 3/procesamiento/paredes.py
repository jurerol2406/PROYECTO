import cv2
import numpy as np

def detectar_paredes(bordes):
    if bordes is None or bordes.size == 0:
        return []

    lineas = cv2.HoughLinesP(
        bordes,
        rho=1,
        theta=np.pi/180,
        threshold=80,
        minLineLength=50,
        maxLineGap=5
    )

    if lineas is None:
        return []

    return [tuple(l[0]) for l in lineas]
