import cv2
import numpy as np

def detectar_habitaciones(bordes):
    if bordes is None or bordes.size == 0:
        return []

    contornos, _ = cv2.findContours(bordes, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    habitaciones = []

    for cnt in contornos:
        area = cv2.contourArea(cnt)
        if area < 500:
            continue

        epsilon = 0.02 * cv2.arcLength(cnt, True)
        approx = cv2.approxPolyDP(cnt, epsilon, True)

        if cv2.isContourConvex(approx):
            habitaciones.append([tuple(pt[0]) for pt in approx])

    return habitaciones
