import cv2

def limpiar_imagen(img):
    gris = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    borroso = cv2.GaussianBlur(gris, (5,5), 0)
    bordes = cv2.Canny(borroso, 50, 150)
    return bordes


def detectar_paredes(bordes):
    lineas = cv2.HoughLinesP(
        bordes,
        rho=1,
        theta=3.14/180,
        threshold=80,
        minLineLength=50,
        maxLineGap=10
    )
    return lineas
