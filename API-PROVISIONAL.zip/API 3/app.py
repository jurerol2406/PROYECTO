import sys
import os
import tempfile
import cv2
import numpy as np
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import Response

# Importar módulos de procesamiento
from procesamiento.limpiar import limpiar_imagen
from procesamiento.paredes import detectar_paredes
from procesamiento.habitaciones import detectar_habitaciones

app = FastAPI(title="API Análisis de Planos", version="1.1")


def preparar_imagen(img):
    if len(img.shape) == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    elif len(img.shape) == 3 and img.shape[2] == 4:
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

    max_dim = 1500
    h, w = img.shape[:2]
    if max(h, w) > max_dim:
        scale = max_dim / max(h, w)
        img = cv2.resize(img, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)

    img = cv2.convertScaleAbs(img, alpha=1.2, beta=10)
    return img


# Conversor universal NumPy → Python
def convertir(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.int32, np.int64, np.intc)):
        return int(obj)
    if isinstance(obj, (np.float32, np.float64)):
        return float(obj)
    if isinstance(obj, dict):
        return {k: convertir(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [convertir(x) for x in obj]
    return obj


# Colorear habitaciones
def colorear_habitaciones(img, habitaciones):
    salida = img.copy()

    for hab in habitaciones:
        pts = np.array(hab, dtype=np.int32)

        color = (
            int(np.random.randint(50, 255)),
            int(np.random.randint(50, 255)),
            int(np.random.randint(50, 255))
        )

        cv2.fillPoly(salida, [pts], color)

    return salida


@app.post("/analizar")
async def analizar_plano(file: UploadFile = File(...)):
    nombre = file.filename.lower()
    if not (nombre.endswith(".jpg") or nombre.endswith(".jpeg") or nombre.endswith(".png")):
        raise HTTPException(status_code=400, detail="Formato no válido. Solo JPG o PNG.")

    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp:
            contenido = await file.read()
            tmp.write(contenido)
            tmp_path = tmp.name

        img = cv2.imread(tmp_path, cv2.IMREAD_UNCHANGED)
        os.remove(tmp_path)

        if img is None:
            raise HTTPException(status_code=415, detail="No se pudo leer la imagen.")

        img_proc = preparar_imagen(img)
        bordes = limpiar_imagen(img_proc)

        lineas = detectar_paredes(bordes)
        habitaciones = detectar_habitaciones(bordes)

        return {
            "status": "ok",
            "paredes_detectadas": convertir(lineas),
            "habitaciones": convertir(habitaciones),
            "numero_habitaciones": int(len(habitaciones))
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/visualizar")
async def visualizar_plano(file: UploadFile = File(...)):
    nombre = file.filename.lower()
    if not (nombre.endswith(".jpg") or nombre.endswith(".jpeg") or nombre.endswith(".png")):
        raise HTTPException(status_code=400, detail="Formato no válido. Solo JPG o PNG.")

    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp:
            contenido = await file.read()
            tmp.write(contenido)
            tmp_path = tmp.name

        img = cv2.imread(tmp_path, cv2.IMREAD_UNCHANGED)
        os.remove(tmp_path)

        if img is None:
            raise HTTPException(status_code=415, detail="No se pudo leer la imagen.")

        img_proc = preparar_imagen(img)
        bordes = limpiar_imagen(img_proc)

        lineas = detectar_paredes(bordes)
        habitaciones = detectar_habitaciones(bordes)

        # Colorear habitaciones
        img_color = colorear_habitaciones(img_proc, habitaciones)

        # Codificar como JPEG
        _, buffer = cv2.imencode(".jpg", img_color)
        return Response(content=buffer.tobytes(), media_type="image/jpeg")

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
